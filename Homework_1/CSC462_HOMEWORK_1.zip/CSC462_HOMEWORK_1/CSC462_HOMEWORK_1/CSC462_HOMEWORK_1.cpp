// CSC462_HOMEWORK_1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <cstring>
#include "CSC462_HOMEWORK_1.h"

int main()
{

    //Setting up 
    std::string sentence;
    std::string word;
    
    while (word != "exit") {
        
        std::cout << "Write a sentence: \n";
        std::getline(std::cin, sentence);

        char* words = new char[sentence.length() + 1];
        char* nxtWord;
        
        strcpy_s(words, sentence.length() + 1, sentence.c_str());
        char* thsWord = strtok_s(words, " ", &nxtWord);
        
        while (thsWord != 0)
        {
            
            word = thsWord;
            if (word == "exit") {
                break;
            }
            
            std::cout << thsWord << '\n';
            thsWord = strtok_s(NULL, " ", &nxtWord);
            
        }
        delete[] words;
    }
    return 0;
    
}